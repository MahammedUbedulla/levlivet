import { Injectable } from '@angular/core';
import { Http, Response } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import 'rxjs/Rx';
import { MyFeedbackInterface } from '../@models/patientFeedback';
import { retry } from 'rxjs/operator/retry';

@Injectable()
export class FeedackService{
     private feedbackurl = "http://ec2-52-38-39-114.us-west-2.compute.amazonaws.com:8080/Medical/ProviderPatFeedback/save";
     
     constructor (private http: Http){
        
     }
     saveRatings(data:any): Observable<MyFeedbackInterface[]>{
        return this.http
                .post(this.feedbackurl,data)
                .map((response : Response) => {
                    return response.json();
                })
                .catch(this.handleError);
     }

     private handleError(error: Response) {
         return Observable.throw(error.statusText);
     }
}