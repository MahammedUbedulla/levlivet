import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { platformBrowserDynamic } from '@angular/platform-browser-dynamic';

import { AppRoutingModule } from './@routing/app-routing.module';
import { FormBuilder, FormGroup, FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpModule } from '@angular/http';
import { RouterModule, Routes } from '@angular/router';

import { AppComponent } from './app.component';
import { LoginComponent } from './@views/login/login.component';
//import { VitalsComponent } from './@views/vitals/vitals.component';
import { FooterComponent } from './@views/footer/footer.component';
import { ProfileComponent } from './@views/profile/profile.component';
import { FeedackService } from './@services/feedback.api.service';
import { RatingDynamicComponent } from './@views/profile/profile.starrating';
import { RatingModule,ProgressbarModule,TooltipModule  } from 'ngx-bootstrap';
import { PharmacydashComponent } from './@views/pharmacydash/pharmacydash.component';
import { PendingOrdersComponent } from './@views/pending-orders/pending-orders.component';
import { TableFilter } from './@views/pending-orders/filter.pipe';
import { YourOrdersComponent } from './@views/your-orders/your-orders.component';
import { PharmOdrDetailsComponent } from './@views/pharm-odr-details/pharm-odr-details.component';
import { LabimagingordComponent } from './@views/labimagingord/labimagingord.component';

import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { NoopAnimationsModule } from '@angular/platform-browser/animations';
//import { Ng2SearchPipeModule } from 'ng2-search-filter';

import {
  MatAutocompleteModule,
  MatButtonModule,
  MatButtonToggleModule,
  MatCardModule,
  MatCheckboxModule,
  MatChipsModule,
  MatDatepickerModule,
  MatDialogModule,
  MatDividerModule,
  MatExpansionModule,
  MatGridListModule,
  MatIconModule,
  MatInputModule,
  MatListModule,
  MatMenuModule,
  MatNativeDateModule,
  MatPaginatorModule,
  MatProgressBarModule,
  MatProgressSpinnerModule,
  MatRadioModule,
  MatRippleModule,
  MatSelectModule,
  MatFormFieldModule,
  MatSidenavModule,
  MatSliderModule,
  MatSlideToggleModule,
  MatSnackBarModule,
  MatSortModule,
  MatStepperModule,
  MatTableModule,
  MatTabsModule,
  MatToolbarModule,
  MatTooltipModule,
} from '@angular/material';

import { SidenavFixedComponent } from './@views/sidenav-fixed/sidenav-fixed.component';
import { WelcomePatientComponent } from './@views/welcome-patient/welcome-patient.component';
import { PharmacyHeaderComponent } from './@views/pharmacy-header/pharmacy-header.component';




@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
   // VitalsComponent,
    FooterComponent,
    ProfileComponent,
    PharmacydashComponent,
    PendingOrdersComponent,
    YourOrdersComponent,
    PharmOdrDetailsComponent,
    SidenavFixedComponent,
    TableFilter,
    LabimagingordComponent,
    WelcomePatientComponent,
    PharmacyHeaderComponent
    //SearchByNamePipe
  ],
  imports: [  
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpModule,
    //RouterModule.forRoot(appRoutes),
    RatingModule.forRoot(),
    ProgressbarModule.forRoot(),
    TooltipModule.forRoot(),
    MatAutocompleteModule,
    MatButtonModule,
    MatButtonToggleModule,
    MatCardModule,
    MatCheckboxModule,
    MatChipsModule,
    MatStepperModule,
    MatDatepickerModule,
    MatDialogModule,
    MatDividerModule,
    MatExpansionModule,
    MatGridListModule,
    MatIconModule,
    MatInputModule,
    MatListModule,
    MatMenuModule,
    MatNativeDateModule,
    MatPaginatorModule,
    MatProgressBarModule,
    MatProgressSpinnerModule,
    MatRadioModule,
    MatRippleModule,
    MatSelectModule,
    MatSidenavModule,
    MatSliderModule,
    MatSlideToggleModule,
    MatSnackBarModule,
    MatSortModule,
    MatTableModule,
    MatTabsModule,
    MatToolbarModule,
    MatTooltipModule,
    MatFormFieldModule,
    FormsModule,
    ReactiveFormsModule,
    BrowserAnimationsModule,
    NoopAnimationsModule,
    //Ng2SearchPipeModule
  ],
  providers: [ FeedackService ],
  bootstrap: [ AppComponent ]
})
export class AppModule { }
platformBrowserDynamic().bootstrapModule(AppModule);