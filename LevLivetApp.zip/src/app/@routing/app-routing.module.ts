import { NgModule } from '@angular/core';

import { LoginComponent } from '../@views/login/login.component';
//import { VitalsComponent } from '../@views/vitals/vitals.component';
import { WelcomePatientComponent } from '../@views/welcome-patient/welcome-patient.component';
import { YourOrdersComponent } from '../@views/your-orders/your-orders.component';
import { PharmOdrDetailsComponent } from '../@views/pharm-odr-details/pharm-odr-details.component';
import { PharmacydashComponent } from '../@views/pharmacydash/pharmacydash.component';
import { PendingOrdersComponent } from '../@views/pending-orders/pending-orders.component';
import { LabimagingordComponent } from '../@views/labimagingord/labimagingord.component';

import { Routes, RouterModule } from '@angular/router';

const appRoutes: Routes = [
  { path: 'pendingorders', component: PendingOrdersComponent },
  { path: 'yourorders',  component: YourOrdersComponent },
  { path: 'pharmaorderdetails',  component: PharmOdrDetailsComponent },
  { path: 'labimagingord',  component: LabimagingordComponent },
  { path: 'welcomepatient',  component: WelcomePatientComponent },
  { path: '',   redirectTo: 'pendingorders', pathMatch: 'full' }
];

@NgModule({
  imports: [RouterModule.forRoot(appRoutes)],
  exports: [RouterModule]
})
export class AppRoutingModule {
  
 }
