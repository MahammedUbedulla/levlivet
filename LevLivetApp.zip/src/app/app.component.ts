import { Component, OnInit } from '@angular/core';
import { LoginComponent } from './@views/login/login.component';
//import { VitalsComponent } from './@views/vitals/vitals.component';
import { RatingDynamicComponent, RatingBasicComponent } from './@views/profile/profile.starrating';

import { MyFeedbackInterface } from './@models/patientFeedback';
import { error } from 'util';



@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  feedbackArray: MyFeedbackInterface[];

    constructor (){

    }

    ngOnInIt() : void{
     
    }
}
