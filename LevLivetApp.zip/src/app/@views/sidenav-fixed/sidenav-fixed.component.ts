import { Component, OnInit } from '@angular/core';
import {FormControl, ReactiveFormsModule} from '@angular/forms';

@Component({
  selector: 'app-sidenav-fixed',
  templateUrl: './sidenav-fixed.component.html',
  styleUrls: ['./sidenav-fixed.component.css']
})
export class SidenavFixedComponent implements OnInit {

  constructor() { }

  mode = new FormControl('over');

  ngOnInit() {
  }

}
