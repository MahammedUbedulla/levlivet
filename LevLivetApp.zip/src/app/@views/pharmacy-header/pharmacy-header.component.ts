import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-pharmacy-header',
  templateUrl: './pharmacy-header.component.html',
  styleUrls: ['./pharmacy-header.component.css']
})
export class PharmacyHeaderComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
