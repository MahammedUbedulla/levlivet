import { Component, ViewChild, OnInit } from '@angular/core';
import { MatPaginator, MatTableDataSource } from '@angular/material';

@Component({
  selector: 'app-pharm-odr-details',
  templateUrl: './pharm-odr-details.component.html',
  styleUrls: ['./pharm-odr-details.component.css']
})
export class PharmOdrDetailsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }
  displayedColumns = ['prescription_name', 'strength', 'total_quality', 'duration', 'dosage', 'issued', 'perctgorddel'];
  dataSource = new MatTableDataSource<Element>(ELEMENT_DATA);

  @ViewChild(MatPaginator) paginator: MatPaginator;

  /**
   * Set the paginator after the view init since this component will
   * be able to query its view for the initialized paginator.
   */
  ngAfterViewInit() {
    this.dataSource.paginator = this.paginator;
  }


}

export interface Element {
  strength: string;
  prescription_name: string;
  total_quality: number;
  duration: string;
  dosage: string;
  issued:string;
  perctgorddel:number;
}

const ELEMENT_DATA: Element[] = [
  {prescription_name: 'Zantac 300', strength: '300 mg', total_quality: 7, duration: '3 Days', dosage: '2 / Day',issued: 'Name', perctgorddel:70},
  {prescription_name: 'Zantac 300', strength: '300 mg', total_quality: 7, duration: '3 Days', dosage: '2 / Day',issued: 'Name', perctgorddel:70}
];

