import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PharmOdrDetailsComponent } from './pharm-odr-details.component';

describe('PharmOdrDetailsComponent', () => {
  let component: PharmOdrDetailsComponent;
  let fixture: ComponentFixture<PharmOdrDetailsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PharmOdrDetailsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PharmOdrDetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
