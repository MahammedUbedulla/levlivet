import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-welcome-patient',
  templateUrl: './welcome-patient.component.html',
  styleUrls: ['./welcome-patient.component.css']
})
export class WelcomePatientComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

  //Table of My Appointments
  myAppointmentsTableColms = ['category', 'name', 'date', 'time'];
  myAppointments = myAppointments;

  // Tables For Current Preferences

    //Doctor Table
    CurrentPrefDoctorTableColms = ['name', 'specialization', 'MRen'];
    CurrentPrefDoctorTable = curprefdtcrtable;

    //Pharmacy Table
    CurrentPrefPharmacyTableColms = ['name', 'specialization', 'MRen'];
    CurrentPrefPharmacyTable = curprefpharmtable;

    //Lab Table
    CurrentPrefLabTableColms = ['name', 'specialization', 'MRen'];
    CurrentPrefLabTable = curpreflabtable;

    //Imaging Table
    CurrentPrefImagingTableColms = ['name', 'specialization', 'MRen'];
    CurrentPreImagingTable = curprefimagingtable;

 // Tables For Previous Visits

    //Doctor Table
    PrevVisitsDoctorTableColms = ['name', 'specialization', 'MRen'];
    PrevVisitsDoctorTable = prevvisistsdtcrtable;

    //Pharmacy Table
    PrevVisitsPharmacyTableColms = ['name', 'specialization', 'MRen'];
    PrevVisitsPharmacyTable = prevvisistspharmtable;

    //Lab Table
    PrevVisitsLabTableColms = ['name', 'specialization', 'MRen'];
    PrevVisitsLabTable = prevvisistslabtable;

    //Imaging Table
    PrevVisitsImagingTableColms = ['name', 'specialization', 'MRen'];
    PrevVisitsImagingTable = prevvisistsimagingtable;

}

//Table of My Appointments
export interface myAppointmentsElemnts {
  name: string;
  category: string;
  date: number;
  time: string;
}
const myAppointments: myAppointmentsElemnts[] = [
  {category: 'Hospital Pharmacy', name: 'Hospital Pharmacy', date: 1, time: '9.10 AM'},
  {category: 'Clinical Pharmacy', name: 'Hospital Pharmacy', date: 1, time: '9.00 AM'},
  {category: 'Industrial Pharmacy', name: 'Industrial Pharmacy', date: 1, time: '10.00 AM'},
  {category: 'Hospital Pharmacy', name: 'Hospital Pharmacy', date: 1, time: '9.30 AM'}
];


// Tables For Current Preferences

  //Doctor Table
  export interface curPrefDtcrtableElms {
    name: string;
    specialization: string;
    MRen: number;
  }
  const curprefdtcrtable: curPrefDtcrtableElms[] = [
    {name: 'Hospital Pharmacy', specialization: 'Hospital Pharmacy', MRen: 1}
  ];

  //Pharmacy Table
  export interface curPrefpharmatableElms {
    name: string;
    specialization: string;
    MRen: number;
  }
  const curprefpharmtable: curPrefpharmatableElms[] = [
    {name: 'Hospital Pharmacy2', specialization: 'Hospital Pharmacy2', MRen: 2}
  ];

  //Lab Table
  export interface curPrefLabtableElms {
    name: string;
    specialization: string;
    MRen: number;
  }
  const curpreflabtable: curPrefLabtableElms[] = [
    {name: 'Hospital Pharmacy3', specialization: 'Hospital Pharmacy3', MRen: 3}
  ];

  //Imaging Table
  export interface curPrefImagingtableElms {
    name: string;
    specialization: string;
    MRen: number;
  }
  const curprefimagingtable: curPrefImagingtableElms[] = [
    {name: 'Hospital Pharmacy4', specialization: 'Hospital Pharmacy4', MRen: 4}
  ];


// Tables For Previous Visists

  //Doctor Table
  export interface PrevVisitsDtcrtableElms {
    name: string;
    specialization: string;
    MRen: number;
  }
  const prevvisistsdtcrtable: PrevVisitsDtcrtableElms[] = [
    {name: 'Hospital Pharmacy Prev', specialization: 'Hospital Pharmacy', MRen: 1}
  ];

  //Pharmacy Table
  export interface PrevVisitspharmatableElms {
    name: string;
    specialization: string;
    MRen: number;
  }
  const prevvisistspharmtable: PrevVisitspharmatableElms[] = [
    {name: 'Hospital Pharmacy Prev2', specialization: 'Hospital Pharmacy2', MRen: 2}
  ]; 

  //Lab Table
  export interface PrevVisitsLabtableElms {
    name: string;
    specialization: string;
    MRen: number;
  }
  const prevvisistslabtable: PrevVisitsLabtableElms[] = [
    {name: 'Hospital Pharmacy Prev3', specialization: 'Hospital Pharmacy3', MRen: 3}
  ];

  //Imaging Table
  export interface PrevVisitsImagingtableElms {
    name: string;
    specialization: string;
    MRen: number;
  }
  const prevvisistsimagingtable: PrevVisitsImagingtableElms[] = [
    {name: 'Hospital Pharmacy Prev4', specialization: 'Hospital Pharmacy4', MRen: 4}
  ];