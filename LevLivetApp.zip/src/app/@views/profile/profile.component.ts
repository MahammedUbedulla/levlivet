import { Component, OnInit } from '@angular/core';
import { FeedackService } from '../../@services/feedback.api.service';

@Component({
  selector: 'app-profile',
  templateUrl: './profile.component.html',
  styleUrls: ['./profile.component.css']
})
export class ProfileComponent implements OnInit {
localData:any;
resultArray:any;
saved:any;
  constructor (private feedbackservice: FeedackService){
    
  }

    saverating(): void {
      this.localData={
        "docId":1000,
        "facilityId":1002,
        "fbMrn":"adada412222222222222222222",
        "fbName":"adada",
        "fbCityState":"adada",
        "fbGender":"M",
        "fbAgeGroup":"ad",
        "fbNoVisitsLast12mon":"13",
        "fbEmail":"afafa@tt.com",
        "fbPhNum":"4567891230",
        "fbEsu":5,
        "fbOec":2,
        "fbSfc":3,
        "fbTwt":4,
        "fbLot":4,
        "fbPem":3,
        "fbPlaq":2,
        "fbSat":4,
        "fbPatRecommend":2
      };

      this.feedbackservice.saveRatings(this.localData)
            .subscribe(
                resultArray => this.saved = resultArray,
                error => console.log("Error ::" + error)
            )    
            
      console.log(this.saved);
    }

    ngOnInit(){       
    }

    // This is for Select Value in Profile Model ---Select Wait Time
    selectedValue: string;
    selectwaittimes = [
      {value: 'under10mins', viewValue: 'Under 10 Minutes'},
      {value: '10to15mins', viewValue: '10 - 15 Minutes'},
      {value: '16to30mins', viewValue: '16 - 30 Minutes'},
      {value: '31to45mins', viewValue: '31 - 45 Minutes'},
      {value: 'over45mins', viewValue: 'Over 45 Minutes'}
    ];


// START - Created the Star Rating for Profile page in Model

   // title = 'Star Rating';  
    starList: boolean[] = [true,true,true,true,true]; 
    starList2: boolean[] = [true,true,true,true,true];
    starList3: boolean[] = [true,true,true,true,true];
    starList4: boolean[] = [true,true,true,true,true];
    starList5: boolean[] = [true,true,true,true,true];
    starList6: boolean[] = [true,true,true,true,true];
    starList7: boolean[] = [true,true,true,true,true];
    starList8: boolean[] = [true,true,true,true,true];

    rating_familyfrnds:number;
    rating_name_familyfrnds:string;

    //Create a function which receives the value counting of stars click, 
    //and according to that value we do change the value of that star in list.

    setStar(data:any){
        this.rating_familyfrnds=data+1;                               
        for(var i=0;i<=4;i++){  
          if(i<=data){  
            this.starList[i]=false;  
          }  
          else{  
            this.starList[i]=true; 
          }  
        }
        
        if(this.rating_familyfrnds == 5){
          this.rating_name_familyfrnds = 'Excellent';
        }else if(this.rating_familyfrnds == 4){
          this.rating_name_familyfrnds = 'Good';
        }else if(this.rating_familyfrnds == 3){
          this.rating_name_familyfrnds = 'Not Bad';
        }else{
          this.rating_name_familyfrnds = 'Poor';
        }
    }

//This is created for Rating of "Ease of scheduling urgent appointments"
rating_schedule:number;
rating_name_schedule:string;

    setStarSchedule(data:any){      
      this.rating_schedule=data+1;                               
      for(var i=0;i<=4;i++){  
        if(i<=data){  
          this.starList2[i]=false;  
        }  
        else{  
          this.starList2[i]=true; 
        }  
      }
      
      if(this.rating_schedule == 5){
        this.rating_name_schedule = 'Excellent';
      }else if(this.rating_schedule == 4){
        this.rating_name_schedule = 'Good';
      }else if(this.rating_schedule == 3){
        this.rating_name_schedule = 'Not Bad';
      }else{
        this.rating_name_schedule = 'Poor';
      }
  }

//This is created for Rating of "Office environment, cleanliness, comfort, etc."

  rating_offcenvrncleaning:number;
  rating_name_offcenvrncleaning:string;
  
  setStarOffcCleaning(data:any){  
      this.rating_offcenvrncleaning=data+1;                               
      for(var i=0;i<=4;i++){  
        if(i<=data){  
          this.starList3[i]=false;  
        }  
        else{  
          this.starList3[i]=true; 
        }  
      }
      
      if(this.rating_offcenvrncleaning == 5){
        this.rating_name_offcenvrncleaning = 'Excellent';
      }else if(this.rating_offcenvrncleaning == 4){
        this.rating_name_offcenvrncleaning = 'Good';
      }else if(this.rating_offcenvrncleaning == 3){
        this.rating_name_offcenvrncleaning = 'Not Bad';
      }else{
        this.rating_name_offcenvrncleaning = 'Poor';
      }
  }
    

  //This is created for Rating of "Staff friendliness and courteousness"

  rating_stafffrndns:number;
  rating_name_stafffrndns:string;
  
  setStarStaffFrndns(data:any){  
      this.rating_stafffrndns=data+1;                               
      for(var i=0;i<=4;i++){  
        if(i<=data){  
          this.starList4[i]=false;  
        }  
        else{  
          this.starList4[i]=true; 
        }  
      }
      
      if(this.rating_stafffrndns == 5){
        this.rating_name_stafffrndns = 'Excellent';
      }else if(this.rating_stafffrndns == 4){
        this.rating_name_stafffrndns = 'Good';
      }else if(this.rating_stafffrndns == 3){
        this.rating_name_stafffrndns = 'Not Bad';
      }else{
        this.rating_name_stafffrndns = 'Poor';
      }
  }

  //This is created for Rating of "Level of trust in provider's decisions"

  rating_leveltrust:number;
  rating_name_leveltrust:string;
  
  setStarLevelTruseDec(data:any){  
      this.rating_leveltrust=data+1;                               
      for(var i=0;i<=4;i++){  
        if(i<=data){  
          this.starList5[i]=false;  
        }  
        else{  
          this.starList5[i]=true; 
        }  
      }
      
      if(this.rating_leveltrust == 5){
        this.rating_name_leveltrust = 'Excellent';
      }else if(this.rating_leveltrust == 4){
        this.rating_name_leveltrust = 'Good';
      }else if(this.rating_leveltrust == 3){
        this.rating_name_leveltrust = 'Not Bad';
      }else{
        this.rating_name_leveltrust = 'Poor';
      }
  }

//This is created for Rating of "How well provider explains medical condition(s)"

  rating_medicalcondns:number;
  rating_name_medicalcondns:string;
  
  setStarMedicalCondtns(data:any){  
      this.rating_medicalcondns=data+1;                               
      for(var i=0;i<=4;i++){  
        if(i<=data){  
          this.starList6[i]=false;  
        }  
        else{  
          this.starList6[i]=true; 
        }  
      }
      
      if(this.rating_medicalcondns == 5){
        this.rating_name_medicalcondns = 'Excellent';
      }else if(this.rating_medicalcondns == 4){
        this.rating_name_medicalcondns = 'Good';
      }else if(this.rating_medicalcondns == 3){
        this.rating_name_medicalcondns = 'Not Bad';
      }else{
        this.rating_name_medicalcondns = 'Poor';
      }
  }

  //This is created for Rating of "How well provider listens and answers questions"

  rating_ansquents:number;
  rating_name_ansquents:string;
  
  setStarAnsQuetns(data:any){  
      this.rating_ansquents=data+1;                               
      for(var i=0;i<=4;i++){  
        if(i<=data){  
          this.starList7[i]=false;  
        }  
        else{  
          this.starList7[i]=true; 
        }  
      }
      
      if(this.rating_ansquents == 5){
        this.rating_name_ansquents = 'Excellent';
      }else if(this.rating_ansquents == 4){
        this.rating_name_ansquents = 'Good';
      }else if(this.rating_ansquents == 3){
        this.rating_name_ansquents = 'Not Bad';
      }else{
        this.rating_name_ansquents = 'Poor';
      }
  }

  //This is created for Rating of "Spends appropriate amount of time with patients"

  rating_timewithptns:number;
  rating_name_timewithptns:string;
  
  setStarTimeWithPtns(data:any){  
      this.rating_timewithptns=data+1;                               
      for(var i=0;i<=4;i++){  
        if(i<=data){  
          this.starList8[i]=false;  
        }  
        else{  
          this.starList8[i]=true; 
        }  
      }
      
      if(this.rating_timewithptns == 5){
        this.rating_name_timewithptns = 'Excellent';
      }else if(this.rating_timewithptns == 4){
        this.rating_name_timewithptns = 'Good';
      }else if(this.rating_timewithptns == 3){
        this.rating_name_timewithptns = 'Not Bad';
      }else{
        this.rating_name_timewithptns = 'Poor';
      }
  }



//Created for Doctor Information Table in Profile Page

displayedColumns = ['facility', 'location', 'workingdays', 'timings', 'consultaion_fee', 'bookappmnt'];
dataSource = DctrProfileData;

}

export interface Element {
  facility: string;
  location: string;
  workingdays: number;
  timings: string;
  consultaion_fee: string;
  bookappmnt: string;
}

const DctrProfileData: Element[] = [
  { facility: 'John', location: 'Hyderabad, Bangaloore, Chennai', workingdays: 5 , timings: '12AM - 7AM', consultaion_fee: '$50', bookappmnt: '' }
];