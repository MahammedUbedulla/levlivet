import { Component, OnInit } from '@angular/core';
import { FeedackService } from '../../@services/feedback.api.service';

@Component({
  selector: 'app-profile',
  templateUrl: './profile.component.html',
  styleUrls: ['./profile.component.css']
})

export class RatingBasicComponent {
    max_drtab: number = 10;
    rate_drtab: number = 7;
    isReadonly: boolean = true;
}

export class RatingDynamicComponent {

    title = 'Star Rating';  
    starList: boolean[] = [true,true,true,true,true]; 

    rating:number;  
    //Create a function which receives the value counting of stars click, 
    //and according to that value we do change the value of that star in list.
    setStar(data:any){
        this.rating=data+1;                               
        for(var i=0;i<=4;i++){  
          if(i<=data){  
            this.starList[i]=false;  
          }  
          else{  
            this.starList[i]=true; 
          }  
        }  
    }
}

// ReadOnly Rating in Dr. Reviews tab

