import { Component, ViewChild, OnInit } from '@angular/core';
import { MatPaginator, MatTableDataSource } from '@angular/material';

@Component({
  selector: 'app-your-orders',
  templateUrl: './your-orders.component.html',
  styleUrls: ['./your-orders.component.css']
})
export class YourOrdersComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }


  //START -- Toggle tab for table Name and Contact
        IsHiddenName= true;
        IsHiddenPh = true;

        onSelectName(){
        this.IsHiddenName= !this.IsHiddenName;
        }
        onSelectPh(){
          this.IsHiddenPh= !this.IsHiddenPh;
        }
   
        //showHide: false;
  // End -- Toggle 


  displayedColumns = ['order', 'pt_name', 'contactno', 'medictn_cnt', 'prescriptnsource', 'perctgorddel'];
  dataSource = new MatTableDataSource<Element>(ELEMENT_DATA);
      

  // This is created for Filter in Data Table
  applyFilter(filterValue: string) {
    filterValue = filterValue.trim(); // Remove whitespace
    filterValue = filterValue.toLowerCase(); // MatTableDataSource defaults to lowercase matches
    this.dataSource.filter = filterValue;
  }

  
  @ViewChild(MatPaginator) paginator: MatPaginator;

  /**
   * Set the paginator after the view init since this component will
   * be able to query its view for the initialized paginator.
   */
  ngAfterViewInit() {
    this.dataSource.paginator = this.paginator;
  }


}

export interface Element {
  pt_name: string;
  order: number;
  contactno: number;
  medictn_cnt: number;
  perctgorddel:number;
  prescriptnsource:string;
}

const ELEMENT_DATA: Element[] = [
  {order: 5012, pt_name: 'Jacob', contactno: +919666293535, medictn_cnt: 9, prescriptnsource: 'Thomas', perctgorddel:70},
  {order: 5012, pt_name: 'Jacob', contactno: +919666293535, medictn_cnt: 9, prescriptnsource: 'Thomas', perctgorddel:60},
  {order: 5012, pt_name: 'Jacob', contactno: +919666293535, medictn_cnt: 9, prescriptnsource: 'Thomas', perctgorddel:40},
  {order: 5012, pt_name: 'Jacob', contactno: +919666293535, medictn_cnt: 9, prescriptnsource: 'Thomas', perctgorddel:55},
  {order: 5012, pt_name: 'Jacob', contactno: +919666293535, medictn_cnt: 9, prescriptnsource: 'Thomas', perctgorddel:80},
  {order: 5012, pt_name: 'Jacob', contactno: +919666293535, medictn_cnt: 9, prescriptnsource: 'Thomas', perctgorddel:90},
  {order: 5012, pt_name: 'Jacob', contactno: +919666293535, medictn_cnt: 9, prescriptnsource: 'Thomas', perctgorddel:90},
  {order: 5012, pt_name: 'Jacob', contactno: +919666293535, medictn_cnt: 9, prescriptnsource: 'Thomas', perctgorddel:95},
  {order: 5012, pt_name: 'Jacob', contactno: +919666293535, medictn_cnt: 9, prescriptnsource: 'Thomas', perctgorddel:100}
];


