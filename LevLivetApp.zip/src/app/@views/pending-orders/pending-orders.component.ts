import { Component, ViewChild, OnInit } from '@angular/core';
import { MatPaginator, MatTableDataSource } from '@angular/material';
import { Pipe, PipeTransform } from '@angular/core';

@Component({
  selector: 'app-pending-orders',
  templateUrl: './pending-orders.component.html',
  styleUrls: ['./pending-orders.component.css']
})


export class PendingOrdersComponent implements OnInit {
  searchText = '';
  
  constructor() { }

  displayedColumns = ['order', 'pt_name', 'contactno', 'medictn_cnt', 'order_date', 'prescriptnsource'];
  dataSource = new MatTableDataSource<Element>(ELEMENT_DATA);

  @ViewChild(MatPaginator) paginator: MatPaginator;

  /**
   * Set the paginator after the view init since this component will
   * be able to query its view for the initialized paginator.
   */
  ngAfterViewInit() {
    this.dataSource.paginator = this.paginator;
  }
  
  ngOnInit() {
  }

  //START -- Toggle tab for table Name and Contact
      IsHiddenName= true;
      IsHiddenPh = true;

      onSelectName(){
      this.IsHiddenName= !this.IsHiddenName;
      }
      onSelectPh(){
        this.IsHiddenPh= !this.IsHiddenPh;
      }
      
   //showHide: false;
 // End -- Toggle 

 // this is for Filter a String of Table
   public searchString: string;

   applyFilter(filterValue: string) {
    filterValue = filterValue.trim(); // Remove whitespace
    filterValue = filterValue.toLowerCase(); // MatTableDataSource defaults to lowercase matches
    this.dataSource.filter = filterValue;
  }
   
}

export interface Element {
  pt_name: string;
  order: number;
  contactno: number;
  medictn_cnt: number;
  order_date:number;
  prescriptnsource:string;
}

const ELEMENT_DATA: Element[] = [
  {order: 5012, pt_name: 'Jacob', contactno: +919666293535, medictn_cnt: 9, order_date:1, prescriptnsource: 'Thomas'},
  {order: 5012, pt_name: 'Taylor', contactno: +919666293435, medictn_cnt: 9, order_date:2, prescriptnsource: 'Thomas'},
  {order: 5012, pt_name: 'Taylor', contactno: +919666293434, medictn_cnt: 9, order_date:3, prescriptnsource: 'Thomas'},
  {order: 5012, pt_name: 'Jacob', contactno: +919666293535, medictn_cnt: 9, order_date:4, prescriptnsource: 'Thomas'},
  {order: 5012, pt_name: 'Sam', contactno: +919666292525, medictn_cnt: 9, order_date:5, prescriptnsource: 'Thomas'},
  {order: 5012, pt_name: 'Chayy', contactno: +919666293535, medictn_cnt: 9, order_date:6, prescriptnsource: 'Thomas'},
  {order: 5012, pt_name: 'Chayy', contactno: +919666291515, medictn_cnt: 9, order_date:7, prescriptnsource: 'Thomas'},
  {order: 5012, pt_name: 'Jacob', contactno: +919666293535, medictn_cnt: 9, order_date:8, prescriptnsource: 'Thomas'}
];

// Custome Pipe for Search Name

/*@Pipe({ name: 'searchByName' })
export class SearchByNamePipe implements PipeTransform {
  transform(patientName: Element[], searchText: string) {
    return patientName.filter(pt_name=&amp;gt; Element.name.indexOf(searchText) !== -1);
  }
}*/