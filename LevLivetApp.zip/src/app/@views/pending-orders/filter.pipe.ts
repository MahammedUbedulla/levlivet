import {Injectable, Pipe, PipeTransform} from '@angular/core';
import { PendingOrdersComponent } from './pending-orders.component'

@Pipe({
  name: 'tableFilter'
})

@Injectable()
export class TableFilter implements PipeTransform {
    transform(items: any[], field: string, value: string): any[] {
        if (!items) {
            return [];
        }
        if (!field || !value) {
            return items;
        }

        return items.filter(singleItem => singleItem[field].toLowerCase().includes(value.toLowerCase()));
    }
}