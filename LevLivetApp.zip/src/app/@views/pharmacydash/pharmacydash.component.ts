import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-pharmacydash',
  templateUrl: './pharmacydash.component.html',
  styleUrls: ['./pharmacydash.component.css']
})
export class PharmacydashComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
