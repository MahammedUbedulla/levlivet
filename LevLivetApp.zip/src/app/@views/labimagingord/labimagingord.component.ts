import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-labimagingord',
  templateUrl: './labimagingord.component.html',
  styleUrls: ['./labimagingord.component.css']
})
export class LabimagingordComponent implements OnInit {

  //Declaring the variavles of Patient Details
  name: string;
  contact: number;
  gender: string;
  membershipid: string;
  age: number;
  orderno: number;
  vitals: string;
  symptoms: string;
  medication: string;

  constructor() { 
    this.name= 'Taylor';
    this.contact= +91-9666293535;
    this.gender= 'Female';
    this.membershipid= 'EFG5HH74897';
    this.age= 24;
    this.orderno= 52156745;
    this.vitals= "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries";

    this.symptoms= "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries";
    
    this.medication= "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries";
  }

  // This is for Lab/Imaging Table
  displayedColumns = ['test_name', 'quantity', 'instructions', 'status'];
  dataSource = LabImageTable;

  ngOnInit() {
  }


}

// This is for Lab/Imaging Table

export interface Labimgtable {
  test_name: string;
  quantity: number;
  instructions: string;
  status: string;
}
const LabImageTable: Labimgtable[] = [
  {test_name: 'Zintac300', quantity: 10, instructions: 'Use daily two times, Morning and Night', status: 'Using'},
  {test_name: 'Zintac300', quantity: 10, instructions: 'Use daily two times, Morning and Night', status: 'Using'},
  {test_name: 'Zintac300', quantity: 10, instructions: 'Use daily two times, Morning and Night', status: 'Using'}
];
