/**
 * @author mrdoob / http://mrdoob.com/
 */

var Stats = function () {
	
		var mode = 0;
	
		var container = document.createElement( 'div' );
		container.style.cssText = 'cursor:pointer;opacity:0.9';
		container.addEventListener( 'click', function ( event ) {
	
			event.preventDefault();
			showPanel( ++ mode % container.children.length );
	
		}, false );
	
		//
	
		function addPanel( panel ) {
	
			container.appendChild( panel.dom );
			return panel;
	
		}
	
		function showPanel( id ) {
	
			for ( var i = 0; i < container.children.length; i ++ ) {
	
				container.children[ i ].style.display = i === id ? 'block' : 'none';
	
			}
	
			mode = id;
	
		}
	
		//
	
		var beginTime = ( performance || Date ).now(), prevTime = beginTime, frames = 0;
	
		var fpsPanel = addPanel( new Stats.Panel( 'FPS', '#0ff', '#002' ) );
		var msPanel = addPanel( new Stats.Panel( 'MS', '#0f0', '#020' ) );
	
		if ( self.performance && self.performance.memory ) {
	
			var memPanel = addPanel( new Stats.Panel( 'MB', '#f08', '#201' ) );
	
		}
	
		showPanel( 0 );
	
		return {
	
			REVISION: 16,
	
			domElement: container,
	
			addPanel: addPanel,
			showPanel: showPanel,
	
			setMode: showPanel, // backwards compatibility
	
			begin: function () {
	
				beginTime = ( performance || Date ).now();
	
			},
	
			end: function () {
	
				frames ++;
	
				var time = ( performance || Date ).now();
	
				msPanel.update( time - beginTime, 200 );
	
				if ( time > prevTime + 1000 ) {
	
					fpsPanel.update( ( frames * 1000 ) / ( time - prevTime ), 100 );
	
					prevTime = time;
					frames = 0;
	
					if ( memPanel ) {
	
						var memory = performance.memory;
						memPanel.update( memory.usedJSHeapSize / 1048576, memory.jsHeapSizeLimit / 1048576 );
	
					}
	
				}
	
				return time;
	
			},
	
			update: function () {
	
				beginTime = this.end();
	
			}
	
		};
	
	};
	
	Stats.Panel = function ( name, fg, bg ) {
	
		var min = Infinity, max = 0, round = Math.round;
		var PR = round( window.devicePixelRatio || 1 );
	
		var WIDTH = 80 * PR, HEIGHT = 48 * PR,
				TEXT_X = 3 * PR, TEXT_Y = 2 * PR,
				GRAPH_X = 3 * PR, GRAPH_Y = 15 * PR,
				GRAPH_WIDTH = 74 * PR, GRAPH_HEIGHT = 30 * PR;
	
		var canvas = document.createElement( 'canvas' );
		canvas.width = WIDTH;
		canvas.height = HEIGHT;
		canvas.style.cssText = 'width:80px;height:48px';
	
		var context = canvas.getContext( '2d' );
		context.font = 'bold ' + ( 9 * PR ) + 'px Helvetica,Arial,sans-serif';
		context.textBaseline = 'top';
	
		context.fillStyle = bg;
		context.fillRect( 0, 0, WIDTH, HEIGHT );
	
		context.fillStyle = fg;
		context.fillText( name, TEXT_X, TEXT_Y );
		context.fillRect( GRAPH_X, GRAPH_Y, GRAPH_WIDTH, GRAPH_HEIGHT );
	
		context.fillStyle = bg;
		context.globalAlpha = 0.9;
		context.fillRect( GRAPH_X, GRAPH_Y, GRAPH_WIDTH, GRAPH_HEIGHT );
	
		return {
	
			dom: canvas,
	
			update: function ( value, maxValue ) {
	
				min = Math.min( min, value );
				max = Math.max( max, value );
	
				context.fillStyle = bg;
				context.globalAlpha = 1;
				context.fillRect( 0, 0, WIDTH, GRAPH_Y );
				context.fillStyle = fg;
				context.fillText( round( value ) + ' ' + name + ' (' + round( min ) + '-' + round( max ) + ')', TEXT_X, TEXT_Y );
	
				context.drawImage( canvas, GRAPH_X + PR, GRAPH_Y, GRAPH_WIDTH - PR, GRAPH_HEIGHT, GRAPH_X, GRAPH_Y, GRAPH_WIDTH - PR, GRAPH_HEIGHT );
	
				context.fillRect( GRAPH_X + GRAPH_WIDTH - PR, GRAPH_Y, PR, GRAPH_HEIGHT );
	
				context.fillStyle = bg;
				context.globalAlpha = 0.9;
				context.fillRect( GRAPH_X + GRAPH_WIDTH - PR, GRAPH_Y, PR, round( ( 1 - ( value / maxValue ) ) * GRAPH_HEIGHT ) );
	
			}
	
		};
	
	};
	
	if ( typeof module === 'object' ) {
	
		module.exports = Stats;
	
	}

	
/*
 * requestAnimationFrame pollyfill
 */
if (!window.requestAnimationFrame) {
	window.requestAnimationFrame = (window.webkitRequestAnimationFrame || window.mozRequestAnimationFrame || window.msRequestAnimationFrame || window.oRequestAnimationFrame || function (callback) {
		return window.setTimeout(callback, 1000 / 60);
	});
}

// Init Stats
var stats = new Stats();
stats.setMode(0);
stats.domElement.style.position = 'absolute';
stats.domElement.style.left = '0px';
stats.domElement.style.top = '0px';
document.body.appendChild(stats.domElement);


/*!
 * Mantis.js / jQuery / Zepto.js plugin for Constellation
 * @version 1.2.2
 * @author Acauã Montiel <contato@acauamontiel.com.br>
 * @license http://acaua.mit-license.org/
 */
(function ($, window) {
	/**
	 * Makes a nice constellation on canvas
	 * @constructor Constellation
	 */
	function Constellation (canvas, options) {
		var $canvas = $(canvas),
			context = canvas.getContext('2d'),
			defaults = {
				star: {
					color: 'rgba(255, 255, 255, .5)',
					width: 1,
					randomWidth: true
				},
				line: {
					color: 'rgba(255, 255, 255, .5)',
					width: 0.2
				},
				position: {
					x: 0, // This value will be overwritten at startup
					y: 0 // This value will be overwritten at startup
				},
				width: window.innerWidth,
				height: window.innerHeight,
				velocity: 0.1,
				length: 100,
				distance: 120,
				radius: 150,
				stars: []
			},
			config = $.extend(true, {}, defaults, options);

		function Star () {
			this.x = Math.random() * canvas.width;
			this.y = Math.random() * canvas.height;

			this.vx = (config.velocity - (Math.random() * 0.5));
			this.vy = (config.velocity - (Math.random() * 0.5));

			this.radius = config.star.randomWidth ? (Math.random() * config.star.width) : config.star.width;
		}

		Star.prototype = {
			create: function(){
				context.beginPath();
				context.arc(this.x, this.y, this.radius, 0, Math.PI * 2, false);
				context.fill();
			},

			animate: function(){
				var i;
				for (i = 0; i < config.length; i++) {

					var star = config.stars[i];

					if (star.y < 0 || star.y > canvas.height) {
						star.vx = star.vx;
						star.vy = - star.vy;
					} else if (star.x < 0 || star.x > canvas.width) {
						star.vx = - star.vx;
						star.vy = star.vy;
					}

					star.x += star.vx;
					star.y += star.vy;
				}
			},

			line: function(){
				var length = config.length,
					iStar,
					jStar,
					i,
					j;

				for (i = 0; i < length; i++) {
					for (j = 0; j < length; j++) {
						iStar = config.stars[i];
						jStar = config.stars[j];

						if (
							(iStar.x - jStar.x) < config.distance &&
							(iStar.y - jStar.y) < config.distance &&
							(iStar.x - jStar.x) > - config.distance &&
							(iStar.y - jStar.y) > - config.distance
						) {
							if (
								(iStar.x - config.position.x) < config.radius &&
								(iStar.y - config.position.y) < config.radius &&
								(iStar.x - config.position.x) > - config.radius &&
								(iStar.y - config.position.y) > - config.radius
							) {
								context.beginPath();
								context.moveTo(iStar.x, iStar.y);
								context.lineTo(jStar.x, jStar.y);
								context.stroke();
								context.closePath();
							}
						}
					}
				}
			}
		};

		this.createStars = function () {
			var length = config.length,
				star,
				i;

			context.clearRect(0, 0, canvas.width, canvas.height);

			for (i = 0; i < length; i++) {
				config.stars.push(new Star());
				star = config.stars[i];

				star.create();
			}

			star.line();
			star.animate();
		};

		this.setCanvas = function () {
			canvas.width = config.width;
			canvas.height = config.height;
		};

		this.setContext = function () {
			context.fillStyle = config.star.color;
			context.strokeStyle = config.line.color;
			context.lineWidth = config.line.width;
		};

		this.setInitialPosition = function () {
			if (!options || !options.hasOwnProperty('position')) {
				config.position = {
					x: canvas.width * 0.5,
					y: canvas.height * 0.5
				};
			}
		};

		this.loop = function (callback) {
			callback();

			window.requestAnimationFrame(function () {
				stats.begin(); // Only for Stats
				this.loop(callback);
				stats.end(); // Only for Stats
			}.bind(this));
		};

		this.bind = function () {
			$canvas.on('mousemove', function(e){
				config.position.x = e.pageX - $canvas.offset().left;
				config.position.y = e.pageY - $canvas.offset().top;
			});
		};

		this.init = function () {
			this.setCanvas();
			this.setContext();
			this.setInitialPosition();
			this.loop(this.createStars);
			this.bind();
		};
	}

	$.fn.constellation = function (options) {
		return this.each(function () {
			var c = new Constellation(this, options);
			c.init();
		});
	};
})($, window);

// Init plugin
$('canvas').constellation({
    star: {
        color: 'rgba(255, 255, 255, 0.8)',
        width: 3,
    },
    line: {
        color: 'rgba(39, 210, 51, .5)',
        width: 0.6,
    },
	radius: 250
});
