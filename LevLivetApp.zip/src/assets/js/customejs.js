function LimtCharacters(txtMsg, CharLength, indicator) {
    chars = txtMsg.value.length;
    document.getElementById(indicator).innerHTML = CharLength - chars;
    if (chars > CharLength) {
        txtMsg.value = txtMsg.value.substring(0, CharLength);
    }
}

/*var input, filter, table, matrow, matcell, i;

function searchName() {
    input = document.getElementById("myInput");
    filter = input.value.toUpperCase();
    table = document.getElementById("myTable");
    matrow = table.getElementsByClassName("mat-row");
    for (i = 0; i < matrow.length; i++) {
        matcell = matrow[i].getElementsByClassName("mat-cell")[1];
        if (matcell) {
            if (matcell.innerHTML.toUpperCase().indexOf(filter) > -1) {
                matrow[i].style.display = "";
            } else {
                matrow[i].style.display = "none";
            }
        }       
    }
}

function searchNumber() {    
    input = document.getElementById("myNum").value;
    table = document.getElementById("myTable");
    matrow = table.getElementsByClassName("mat-row");
    for (i = 0; i < matrow.length; i++) {
        matcell = matrow[i].getElementsByClassName("mat-cell")[2];
        if (matcell) {
            if (matcell.innerHTML.indexOf(input) > -1) {
                matrow[i].style.display = "";
            } else {
                matrow[i].style.display = "none";
            }
        }       
    }
}*/


$(document).ready(function() {
	// This for tabs selection
   $(".gender .gender_tab, .agegrp .agegrp_tab, .officevisits .officevisits_tab").click(function(event) {
        event.preventDefault();
        $(this).toggleClass("active");
        $(this).siblings().removeClass("active");
    });

    $(".tabs-menu .tabs_modal").click(function(event) {
        event.preventDefault();
        $(this).addClass("active");
        $(this).siblings().removeClass("active");
        var tab = $(this).attr("href");
        $(".tab_content_eph").not(tab).css("display", "none");
        $(tab).fadeIn();
	});
		
	// This is Star Rating for Individual selection
	/* var append_title;
	
	$(".rating label").hover(		
        function () {
			var append_title = $(this).attr('title');
			//alert(append_title)
			$('.apd_title').addClass('hover_title');
			$('.hover_title').append(append_title);
        },
        function () { 
			$('.apd_title').removeClass('hover_title');
			$('.apd_title').empty();
        },
	); 

	$(".rating a.star").hover(
        function(){
		//$(this).parent().find("a.star").css({"color": "#ebebeb"});
		//$(this).css({"color": "#5a4989"});
		//$(this).nextAll().css({"color": "#5a4989"});
		$(this).prevAll().find("i").attr("class", "fa fa-star");
		$(this).find("i").attr("class", "fa fa-star");
        },
        function(){
            $(this).prevAll().find("i").attr("class", "fa fa-star-o");
		    $(this).find("i").attr("class", "fa fa-star-o");
        },
	);*/

	
	
	/* $("form#feedback_form .rating").submit(function(e) 
    {
	
        e.preventDefault(); // prevent the default click action from being performed
        if ($(".rating :radio:checked").length == 0) {
            alert("nothing checked");
            return false;
        } else {
			//var ratedslection = $('input:radio[name=rating2]:checked').val(); 
           	alert( 'You picked ' + ratedslection);
		}
		
	});*/
	
	// this is for Progress bar Loader
	$(".progress_bar_crcl").loading();

});




	  